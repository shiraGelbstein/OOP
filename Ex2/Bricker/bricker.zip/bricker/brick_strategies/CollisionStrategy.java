package bricker.brick_strategies;

import danogl.GameObject;
/**
 * The CollisionStrategy interface defines methods for handling collision events between game objects.
 */
public interface CollisionStrategy {
    /**
     * Handles the collision event between two game objects.
     * @param gO1 The first game object involved in the collision.
     * @param gO2 The second game object involved in the collision.
     */
    void onCollision(GameObject gO1, GameObject gO2);
}

