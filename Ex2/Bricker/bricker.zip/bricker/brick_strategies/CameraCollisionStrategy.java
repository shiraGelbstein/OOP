package bricker.brick_strategies;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.util.Vector2;
import danogl.gui.rendering.Camera;
import bricker.gameobjects.Ball;
import bricker.gameobjects.CameraManager;

import java.util.Objects;

/**
 * The CameraCollisionStrategy class represents a collision behavior involving a camera.
 * It implements the CollisionStrategy interface.
 */
public class CameraCollisionStrategy implements CollisionStrategy {
    // Instance variable
    private final BrickerGameManager gameManager;

    /**
     * Constructs a CameraCollisionStrategy with the specified BrickerGameManager.
     * @param gameManager The BrickerGameManager instance.
     */
    public CameraCollisionStrategy(BrickerGameManager gameManager) {
        this.gameManager = gameManager;
    }

    /**
     * Handles the collision event between two game objects.
     * @param object1 The first game object involved in the collision.
     * @param object2 The second game object involved in the collision.
     */
    @Override
    public void onCollision(GameObject object1, GameObject object2) {
        gameManager.eraseObject(object1, Layer.DEFAULT);
        if (gameManager.camera() == null  && isMainBallCollision(object2)) {
            gameManager.setCamera(
                    new Camera( gameManager.getBall(), //object to follow
                                Vector2.ZERO, //follow the center of the object
                                gameManager.getWindowDimantions().mult(1.2f), //widen the frame a bit
                                gameManager.getWindowDimantions())); //share the window dimensions
            gameManager.createCameraManager();
        }
        if (gameManager.camera() != null  && gameManager.cameraManager.getCollisionCounter() == 4
                && isMainBallCollision(object2)){
            gameManager.cameraManager.setCollisionCounter();
        }

    }

    /**
     * Checks if the collision involves the main ball.
     * @param object The game object involved in the collision.
     * @return True if the collision involves the main ball, false otherwise.
     */
    private boolean isMainBallCollision(GameObject object) {
        return Objects.equals(object.getTag(), Ball.MAIN_BALL);
    }

}
