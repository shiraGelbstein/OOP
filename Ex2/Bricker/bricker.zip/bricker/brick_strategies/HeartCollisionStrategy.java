package bricker.brick_strategies;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.util.Vector2;

/**
 * Collision strategy for handling collisions with a heart power-up.
 * This strategy creates an extra heart when a collision occurs.
 */
public class HeartCollisionStrategy implements CollisionStrategy {
    // GameManager instance for accessing game state
    private final BrickerGameManager brickerGameManager;

    /**
     * Constructor for HeartCollisionStrategy.
     * @param brickerGameManager The game manager instance.
     */
    public HeartCollisionStrategy(BrickerGameManager brickerGameManager) {
        this.brickerGameManager = brickerGameManager;
    }

    /**
     * Method called on collision.
     * Creates a heart at the center of the brick and removes the collided brick.
     * @param object1 The first game object involved in the collision.
     * @param object2 The second game object involved in the collision.
     */
    @Override
    public void onCollision(GameObject object1, GameObject object2) {
        // Create a heart at the center of the brick
        Vector2 brickCenter = object1.getCenter();
        // Remove the collided brick
        brickerGameManager.eraseObject(object1, Layer.DEFAULT);
        // Create an extra heart
        brickerGameManager.createExtraHeart(brickCenter);
    }
}
