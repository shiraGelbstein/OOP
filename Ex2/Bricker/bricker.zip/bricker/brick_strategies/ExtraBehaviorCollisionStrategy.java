package bricker.brick_strategies;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;

/**
 * Collision strategy for handling extra behavior when a collision occurs.
 * This strategy triggers two random collision strategies obtained from the game manager.
 */
public class ExtraBehaviorCollisionStrategy implements CollisionStrategy{
    // GameManager instance for accessing game state
    private final BrickerGameManager brickerGameManager;
    // Strategies for extra behavior
    private final CollisionStrategy collisionStrategy1;
    private final CollisionStrategy collisionStrategy2;

    /**
     * Constructor for ExtraBehaviorCollisionStrategy.
     * @param brickerGameManager The game manager instance.
     */
    public ExtraBehaviorCollisionStrategy(BrickerGameManager brickerGameManager)
    {
        this.brickerGameManager = brickerGameManager;
        // Get random collision strategies for extra behavior
        this.collisionStrategy1 = brickerGameManager.getRandomStrategyForExtraBehavior();
        this.collisionStrategy2 = brickerGameManager.getRandomStrategyForExtraBehavior();
    }

    /**
     * Method called on collision.
     * Removes the collided brick and triggers the two random collision strategies.
     * @param gO1 The first game object involved in the collision.
     * @param gO2 The second game object involved in the collision.
     */
    @Override
    public void onCollision(GameObject gO1, GameObject gO2) {
        // Remove the collided brick
        brickerGameManager.eraseObject(gO1, Layer.DEFAULT);
        // Apply collision strategies for extra behavior
        collisionStrategy1.onCollision(gO1,gO2);
        collisionStrategy2.onCollision(gO1,gO2);
    }
}
