package bricker.brick_strategies;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.util.Vector2;

/**
 * Collision strategy for handling collisions with a puck power-up.
 * This strategy creates two additional pucks when a collision occurs.
 */
public class PucksCollisionStrategy implements CollisionStrategy{
    // GameManager instance for accessing game state
    BrickerGameManager brickerGameManager;

    /**
     * Constructor for PucksCollisionStrategy.
     * @param brickerGameManager The game manager instance.
     */
    public PucksCollisionStrategy(BrickerGameManager brickerGameManager){
        this.brickerGameManager = brickerGameManager;
    }

    /**
     * Method called on collision.
     * Removes the collided brick and creates two additional pucks at the same location.
     * @param gO1 The first game object involved in the collision.
     * @param gO2 The second game object involved in the collision.
     */
    @Override
    public void onCollision(GameObject gO1, GameObject gO2) {
        // Get the location of the collided brick
        Vector2 location = gO1.getCenter();
        // Remove the collided brick
        brickerGameManager.eraseObject(gO1, Layer.DEFAULT); // removing the brick
        // Create two pucks at the same location
        brickerGameManager.createPuck(location);
        brickerGameManager.createPuck(location);
    }
}
