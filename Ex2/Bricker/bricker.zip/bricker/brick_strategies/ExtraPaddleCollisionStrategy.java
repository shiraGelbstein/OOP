package bricker.brick_strategies;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.util.Vector2;
import bricker.gameobjects.ExtraPaddle;

/**
 * Collision strategy for handling collisions with an extra paddle power-up.
 * This strategy creates an additional paddle when a collision occurs.
 */
public class ExtraPaddleCollisionStrategy implements CollisionStrategy{
    // GameManager instance for accessing game state
    private final BrickerGameManager brickerGameManager;

    /**
     * Constructor for ExtraPaddleCollisionStrategy.
     * @param brickerGameManager The game manager instance.
     */
    public ExtraPaddleCollisionStrategy(BrickerGameManager brickerGameManager) {
        this.brickerGameManager = brickerGameManager;
    }

    /**
     * Method called on collision.
     * Removes the collided brick and creates an additional paddle if there is only one existing.
     * @param gO1 The first game object involved in the collision.
     * @param gO2 The second game object involved in the collision.
     */
    @Override
    public void onCollision(GameObject gO1, GameObject gO2) {
        // Remove the collided brick
        brickerGameManager.eraseObject(gO1, Layer.DEFAULT); //removing the brick
        // Check if there is only one extra paddle, if not, create another one
        if(brickerGameManager.countGameObject(ExtraPaddle.EXTRA_PADDLE)<1){
            //checking if there is more than one paddle
        //creates the second paddle
        brickerGameManager.createExtraPaddle(new Vector2((brickerGameManager.getWindowDimantions().x()/2),
                (brickerGameManager.getWindowDimantions().y()/2)));
        }
    }
}
