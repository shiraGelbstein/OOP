package bricker.brick_strategies;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;

/**
 * The BasicCollisionStrategy class represents a basic collision behavior between game objects.
 * It implements the CollisionStrategy interface and defines the behavior for collision events.
 */
public class BasicCollisionStrategy implements CollisionStrategy{
    BrickerGameManager brickerGameManager;

    /**
     * Constructs a BasicCollisionStrategy with a reference to the BrickerGameManager.
     * @param brickerGameManager The BrickerGameManager instance.
     */
    public BasicCollisionStrategy(BrickerGameManager brickerGameManager){
        this.brickerGameManager = brickerGameManager;
    }

    /**
     * Handles the collision event between two game objects.
     * @param gO1 The first game object involved in the collision.
     * @param gO2 The second game object involved in the collision.
     */
    @Override
    public void onCollision(GameObject gO1, GameObject gO2) {
        brickerGameManager.eraseObject(gO1, Layer.DEFAULT);
    }

}
