package bricker.brick_strategies;

import bricker.main.BrickerGameManager;
import bricker.brick_strategies.StrategyTypes;

/**
 * The StrategyFactory class is responsible for creating specific collision strategies.
 * It provides a method to build collision strategies based on strategy types.
 */
public class StrategyFactory {

    /**
     * defulte constructor
     */
    public StrategyFactory() {}

    /**
     * Builds a collision strategy based on the specified type.
     * @param type The type of collision strategy to build.
     * @param brickerGameManager The BrickerGameManager instance.
     * @return The constructed collision strategy.
     */
    public CollisionStrategy buildStrategy(StrategyTypes type, BrickerGameManager brickerGameManager)
        {
            CollisionStrategy collisionStrategy = null;
            switch (type) {
                case BASIC:
                    collisionStrategy = new BasicCollisionStrategy(brickerGameManager);
                    break;
                case PUCK:
                    collisionStrategy = new PucksCollisionStrategy(brickerGameManager);
                    break;
                case CAMERA:
                    collisionStrategy = new CameraCollisionStrategy(brickerGameManager);
                    break;
                case EXTRA_PADDLE:
                    collisionStrategy = new ExtraPaddleCollisionStrategy(brickerGameManager);
                    break;
                case HEART:
                    collisionStrategy = new HeartCollisionStrategy(brickerGameManager);
                    break;
                case DOUBLE:
                    collisionStrategy = new ExtraBehaviorCollisionStrategy(brickerGameManager);
                    break;
            }
            return collisionStrategy;
        }
    }
