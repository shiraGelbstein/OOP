package bricker.brick_strategies;

/**
 * The StrategyTypes enum represents different types of collision strategies.
 * Each enum constant corresponds to a specific collision behavior.
 */
public enum StrategyTypes {
    /**
     * Represents the basic collision strategy.
     */
    BASIC,

    /**
     * Represents the puck collision strategy.
     */
    PUCK,

    /**
     * Represents the extra paddle collision strategy.
     */
    EXTRA_PADDLE,

    /**
     * Represents the camera collision strategy.
     */
    CAMERA,

    /**
     * Represents the heart collision strategy.
     */
    HEART,

    /**
     * Represents the double collision strategy.
     */
    DOUBLE
}
