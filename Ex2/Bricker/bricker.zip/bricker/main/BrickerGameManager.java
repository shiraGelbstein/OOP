package bricker.main;


import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.Objects;
import java.util.Random;

import bricker.brick_strategies.CollisionStrategy;
import bricker.brick_strategies.StrategyFactory;
import bricker.brick_strategies.StrategyTypes;
import danogl.components.CoordinateSpace;
import danogl.gui.*;
import danogl.gui.rendering.RectangleRenderable;
import bricker.gameobjects.*;
import danogl.GameManager;
import danogl.GameObject;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import danogl.collisions.Layer;

/**
 * The BrickerGameManager class manages the game state, including game objects, collisions, and game logic.
 * It extends the GameManager class and provides functionality specific to the "Bricker" game.
 */
public class BrickerGameManager extends GameManager {

    private static final float BALL_SPEED = 300;
    private static final int DEFAULT_NUM_OF_BRICKS = 8;
    private static final int DEFAULT_NUM_OF_ROWS = 7;
    private static final int DEFAULT_NUM_OF_LIFE = 3;
    private static final int BALL_SIZE = 20;

    // Instance variables
    private final int numOfBricksInRow;
    private final int numOfBrickRows;
    private Ball ball;
    private Vector2 windowDimantions;
    private int curNumOfLife = DEFAULT_NUM_OF_LIFE;
    private WindowController windowController;
    private LifeManager heartsManager;
    private UserInputListener inputListener;
    private ImageReader imageReader;
    private SoundReader soundReader;
    private int ExtraBehaviorStrategyCounter = 0;
    private final int maxCallsToExtraBehavior = 1;
    /**
     * The manager to set the camera on and off due to the ball collides counter.
     */
    public CameraManager cameraManager;

    /**
     * A constructor that gets the argument needed to inisialise
     * a gsme due to DanoGameLab and num of rows and columns
     * of brickes in the game.
     * @param windowTitle
     * @param windowDimensions
     * @param numOfBricksInRow
     * @param numOfBrickRows
     */
    public BrickerGameManager(String windowTitle, Vector2 windowDimensions,
                              int numOfBricksInRow, int numOfBrickRows) {
        super(windowTitle, windowDimensions);
        this.numOfBrickRows = numOfBrickRows;
        this.numOfBricksInRow = numOfBricksInRow;
    }

    /**
     *Defulte constructor. called when not getting 2 arguments in command
     *  line and initialise a game with the defult
     * number of rows and columns.
     * @param windowTitle
     * @param windowDimensions
     */
    public BrickerGameManager(String windowTitle, Vector2 windowDimensions) {
        super(windowTitle, windowDimensions);
        this.numOfBricksInRow = DEFAULT_NUM_OF_BRICKS;
        this.numOfBrickRows = DEFAULT_NUM_OF_ROWS;
    }

    // Getters and setters
    /**
     * Get the window dimensions.
     * @return The dimensions of the game window.
     */
    public Vector2 getWindowDimantions() {
        return windowDimantions;
    }

    /**
     * Set the current number of lives.
     * @param curNumOfLife The current number of lives to set.
     */
    public void setCurNumOfLife(int curNumOfLife) {
        this.curNumOfLife = curNumOfLife;
    }

    /**
     * Get the ball object.
     * @return The ball object.
     */
    public Ball getBall() {
        return ball;
    }

    // Update method
    /**
     * Update the game state.
     * @param deltaTime The time elapsed since the last update.
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        double ballHeight = ball.getCenter().y();
        String prompt = "";
        int noBricksLeft = countGameObject(Brick.BRICK_TAG);

        if (noBricksLeft == 0 || inputListener.isKeyPressed(KeyEvent.VK_W)) {
            prompt = "You win!";
        }
        if (ballHeight > windowDimantions.y()) {

            if (curNumOfLife > 1) {
                curNumOfLife--;
                removeLife();
                putBallInCenter();
            } else {
                prompt = "You Lose!";
            }
        }
        if (!prompt.isEmpty()) {
            if (windowController.openYesNoDialog(prompt + " Play again?")) {
                curNumOfLife = DEFAULT_NUM_OF_LIFE;
                windowController.resetGame();
            } else {
                windowController.closeWindow();
            }
        }
    }

    /**
     * Count the number of game objects with a specific tag.
     * @param tag The tag to search for.
     * @return The number of game objects with the specified tag.
     */
    public int countGameObject(String tag) {
        int gameObjectsCounter = 0;
        for (GameObject gameObject : this.gameObjects().objectsInLayer(Layer.DEFAULT)) {
            if (Objects.equals(gameObject.getTag(), tag)) {
                gameObjectsCounter++;
            }
        }
        return gameObjectsCounter;
    }

    /**
     * Remove a life from the life manager.
     */
    private void removeLife() {
        heartsManager.removeHeart();
    }

    /**
     * Add a life to the life manager.
     */
    public void addLife() {
        heartsManager.addHeart();
    }

    /**
     * Place the ball in the center of the game window.
     */
    private void putBallInCenter() {
        setRandomVelocity(ball);
        ball.setCenter(windowDimantions.mult(0.5f));
        ;
    }

    /**
     * Set a random velocity for the ball object.
     * @param ball The ball object to set the velocity for.
     */
    private void setRandomVelocity(Ball ball) {
        float ballVelX = BALL_SPEED;
        float ballValY = BALL_SPEED;
        Random rand = new Random();
        if (rand.nextBoolean()) {
            ballVelX *= -1;
        }
        if (rand.nextBoolean()) {
            ballValY *= -1;
        }
        ball.setVelocity(new Vector2(ballVelX, ballValY));
    }

    // Initialization method
    /**
     * Initialize the game components.
     * @param imageReader     The image reader object.
     * @param soundReader     The sound reader object.
     * @param inputListener   The input listener object.
     * @param windowController The window controller object.
     */
    @Override
    public void initializeGame(ImageReader imageReader,
                               SoundReader soundReader,
                               UserInputListener inputListener,
                               WindowController windowController) {
        this.windowController = windowController;
        super.initializeGame(imageReader, soundReader, inputListener, windowController);

        this.windowDimantions = windowController.getWindowDimensions();
        this.inputListener = inputListener;
        this.imageReader = imageReader;
        this.soundReader = soundReader;

        createBall();
        createPaddle(new Vector2(windowDimantions.x() / 2, (int) windowDimantions.y() - 30));
        createWall();
        createBackground();
        createBricks();
        createLifeManager();
    }

    /**
     * Create the life manager object.
     */
    private void createLifeManager() {
        LifeManager lifeManager = new LifeManager(new Vector2(20, windowDimantions.y() - 30),
                new Vector2(0, 0), null, this, 3, 4, 20, 20, 2);
        Renderable heartImage = imageReader.readImage("assets/heart.png", true);
        lifeManager.set(heartImage);
        this.heartsManager = lifeManager;
    }

    /**
     * Create an extra heart object at the specified position.
     * @param brickCenter The center position of the brick associated with the heart.
     */
    public void createExtraHeart(Vector2 brickCenter) {
        Renderable heartImage = imageReader.readImage("assets/heart.png", true);
        ExtraHeartStrategy extraHeartStrategy = new ExtraHeartStrategy(this);
        Heart fallingHeart = new ExtraHeart(brickCenter, new Vector2(20, 20), heartImage, extraHeartStrategy);
        gameObjects().addGameObject(fallingHeart);
        fallingHeart.setVelocity(new Vector2(0, 100)); // Fall downwards
    }

    /**
     * Create the camera manager.
     */
    public void createCameraManager(){
        CameraManager cameraManager = new CameraManager(Vector2.ZERO,Vector2.ZERO,null,this);
        gameObjects().addGameObject(cameraManager,Layer.UI);
        this.cameraManager = cameraManager;

    }

    /**
     * Create the ball object.
     */
    private void createBall() {
        Renderable ballImage = imageReader.readImage("assets/ball.png", true);
        Sound collisionSound = soundReader.readSound("assets/blop_cut_silenced.wav");
        Ball ball = new Ball(new Vector2(0, 0), new Vector2(20, 20), ballImage, collisionSound);
        this.ball = ball;
        ball.setCenter(windowDimantions.mult(0.5f));
        gameObjects().addGameObject(ball);
        setRandomVelocity(ball);
    }

    /**
     * Create an extra paddle object at the specified position.
     * @param setCenter The center position to set for the extra paddle.
     */
    public void createExtraPaddle(Vector2 setCenter) {
        Renderable userPeddleImage = imageReader.readImage("assets/paddle.png", false);
        ExtraPaddleStrategy extraPaddleStrategy = new ExtraPaddleStrategy(this.gameObjects());
        ExtraPaddle extraPeddle = new ExtraPaddle(Vector2.ZERO, new Vector2(200, 20), userPeddleImage,
                inputListener, windowDimantions.add(new Vector2(-10, -10)), extraPaddleStrategy);
        extraPeddle.setCenter(setCenter);
        gameObjects().addGameObject(extraPeddle);
    }

    /**
     * Create a puck object at the specified position.
     * @param topLeftCorner The top-left corner position of the puck.
     */
    public void createPuck(Vector2 topLeftCorner) {
        Renderable puckImage = imageReader.readImage("assets/mockBall.png", true);
        Sound collisionSound = soundReader.readSound("assets/blop_cut_silenced.wav");
        PuckGameStrategy gameStrategy = new PuckGameStrategy(this.gameObjects(), windowDimantions);
        Puck puck = new Puck(topLeftCorner, new Vector2(BALL_SIZE * ((float) 3 / 4),
                BALL_SIZE * ((float) 3 / 4)), puckImage, collisionSound, gameStrategy);
        gameObjects().addGameObject(puck);
        setRandomVelocity(puck);
    }

    /**
     * Create the paddle object at the specified position.
     * @param setCenter The center position to set for the paddle.
     */
    private void createPaddle(Vector2 setCenter) {
        Renderable userPeddleImage = imageReader.readImage("assets/paddle.png", false);
        GameObject userPeddle = new Paddle(Vector2.ZERO, new Vector2(200, 20), userPeddleImage,
                inputListener, windowDimantions.add(new Vector2(-10, -10)));
        userPeddle.setCenter(setCenter);
        gameObjects().addGameObject(userPeddle);
    }

    /**
     * Create the boundary wall objects.
     */
    private void createWall() {
        Vector2[][] wallSizes = {
                {Vector2.ZERO, new Vector2(windowDimantions.x(), 10)},
                {new Vector2(windowDimantions.x() - 10, 0), new Vector2(10, windowDimantions.y())},
                {Vector2.ZERO, new Vector2(10, windowDimantions.y())}
        };
        for (int i = 0; i < wallSizes.length; i++) {
            GameObject wall = new GameObject(wallSizes[i][0], wallSizes[i][1],
                    new RectangleRenderable(new Color(0, 0, 0, 0)));
            gameObjects().addGameObject(wall);
        }
    }

    /**
     * Create the background object.
     */
    private void createBackground() {
        Renderable backgroundImage = imageReader.readImage("assets/DARK_BG2_small.jpeg", false);
        GameObject background = new GameObject(Vector2.ZERO,
                new Vector2(windowDimantions.x(), windowDimantions.y()), backgroundImage);
        background.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        gameObjects().addGameObject(background, Layer.BACKGROUND);
    }

    /**
     * Create the brick objects.
     */
    private void createBricks() {
        int brickHeight = 15;
        int brickWidth = (int) ((windowDimantions.x() - 40) / numOfBricksInRow);

        for (int row = 0; row < numOfBrickRows; row++) {
            for (int col = 0; col < numOfBricksInRow; col++) {
                int x = 20 + col * (brickWidth + 2); // Adding space between bricks
                int y = 10 + row * (brickHeight + 2); // Adding space between bricks

                Renderable brickImage = imageReader.readImage("assets/brick.png", false);
                CollisionStrategy collisionStrategy = randomCollisionStrategy();
                Brick brick = new Brick(new Vector2(x, y), new Vector2(brickWidth, brickHeight), brickImage,
                        collisionStrategy);
                gameObjects().addGameObject(brick);
            }
        }
    }

    /**
     * Get a random collision strategy for extra behavior.
     * @return A random collision strategy for extra behavior.
     */
    public CollisionStrategy getRandomStrategyForExtraBehavior() {
        Random rand = new Random();
        StrategyFactory strategyFactory = new StrategyFactory();
        int randomInt;
        if(ExtraBehaviorStrategyCounter >= maxCallsToExtraBehavior){
            randomInt= rand.nextInt(3);
            ExtraBehaviorStrategyCounter = 0;
        }
        else{
            randomInt= rand.nextInt(4);
            if(randomInt == 3){
            ExtraBehaviorStrategyCounter++;}
        }
        return strategyFactory.buildStrategy(StrategyTypes.values()[randomInt + 1], this);
    }

    /**
     * Get a random collision strategy.
     * @return A random collision strategy.
     */
    private CollisionStrategy randomCollisionStrategy() {
        Random rand = new Random();
        CollisionStrategy collisionStrategy;
        StrategyFactory strategyFactory = new StrategyFactory();
        int randomInt = rand.nextInt(10);
        if (randomInt < 5) {
            collisionStrategy = strategyFactory.buildStrategy(StrategyTypes.values()[0], this);
        } else {
            collisionStrategy = strategyFactory.buildStrategy(StrategyTypes.values()[randomInt - 4], this);
        }
        return collisionStrategy;
    }

    /**
     * Remove a game object from the game.
     * @param gameObj The game object to be removed.
     * @param layer   The layer from which to remove the object.
     */
    public void eraseObject(GameObject gameObj, int layer) {
        gameObjects().removeGameObject(gameObj, layer);
    }

    /**
     * Add a game object to the game.
     * @param gameObj The game object to be added.
     * @param layer   The layer on which to add the object.
     */
    public void addObject(GameObject gameObj, int layer) {
        gameObjects().addGameObject(gameObj, layer);
    }

    /**
     * Main method to start the game.
     * @param args Command line arguments (optional).
     */
    public static void main(String[] args) {
        // add getting the args from the command line
        if (args.length == 2) {
            new BrickerGameManager("bricker",
                    new Vector2(700, 500), Integer.parseInt(args[0]), Integer.parseInt(args[1])).run();
        } else {
            new BrickerGameManager("bricker",
                    new Vector2(700, 500)).run();
        }
    }
}