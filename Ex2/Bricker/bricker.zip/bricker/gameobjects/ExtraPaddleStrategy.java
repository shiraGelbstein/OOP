package bricker.gameobjects;

import danogl.collisions.GameObjectCollection;

/**
 * Strategy for handling extra paddle behavior.
 * Manages updating the extra paddle based on collision counter.
 */
public class ExtraPaddleStrategy {
    // Collection of game objects for managing extra paddle
    private final GameObjectCollection gameObjects;

    /**
     * Constructor for ExtraPaddleStrategy.
     * @param gameObjects The collection of game objects.
     */
    public ExtraPaddleStrategy(GameObjectCollection gameObjects) {
        this.gameObjects = gameObjects;
    }

    /**
     * Updates the extra paddle based on the collision counter.
     * If the collision counter reaches a certain threshold, the extra paddle is removed.
     * @param extraPaddle The extra paddle game object.
     */
    public void updateWithCollisionCounter(ExtraPaddle extraPaddle){
        // If collision counter reaches 4, remove the extra paddle
        if(extraPaddle.getCollisionCounter() == 4)
        {
            gameObjects.removeGameObject(extraPaddle);
        }
    }
}
