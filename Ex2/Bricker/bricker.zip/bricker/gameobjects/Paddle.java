package bricker.gameobjects;

import danogl.GameObject;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

import java.awt.event.KeyEvent;

/**
 * Represents a paddle game object in the game.
 * Handles player input for paddle movement.
 */
public class Paddle extends GameObject {
    // Movement speed of the paddle
    private static final float MOVEMENT_SPEED = 300;
    /**
     * Tag for identifying paddle
     */
    public static final String PADDLE = "Paddle";
    // Dimensions of the paddle
    private final Vector2 dimensions;
    // User input listener for paddle movement
    private final UserInputListener userInputListener;
    // Dimensions of the game window
    private final Vector2 windowDimensions;

    /**
     * Constructor for Paddle.
     * @param topLeftCorner The top-left corner position of the paddle.
     * @param dimensions The dimensions of the paddle.
     * @param renderable The renderable for the paddle.
     * @param userInputListener The user input listener for paddle movement.
     * @param windowDimensions The dimensions of the game window.
     */
    public Paddle(Vector2 topLeftCorner, Vector2 dimensions,
                  Renderable renderable, UserInputListener userInputListener
            , Vector2 windowDimensions) {
        super(topLeftCorner, dimensions, renderable);
        this.userInputListener = userInputListener;
        this.windowDimensions = windowDimensions;
        this.dimensions = dimensions;
        this.setTag(PADDLE);
    }

    /**
     * Updates the paddle position based on user input.
     * @param deltaTime The time elapsed since the last frame.
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        Vector2 movementDir = Vector2.ZERO;
        // Handle left movement input
        if (userInputListener.isKeyPressed(KeyEvent.VK_LEFT)) {
            movementDir = movementDir.add(Vector2.LEFT);
        }
        // Ensure paddle stays within left window boundary
        if (this.getCenter().x() - dimensions.x() / 2 < 10) {
            if (movementDir.x() < 0) {
                movementDir = Vector2.ZERO;
            }
        }
        // Handle right movement input
        if (userInputListener.isKeyPressed(KeyEvent.VK_RIGHT)) {
                movementDir = movementDir.add(Vector2.RIGHT);
            }
        // Ensure paddle stays within right window boundary
        if (this.getCenter().x() + dimensions.x() / 2 > windowDimensions.x()) {
                if (movementDir.x() > 0) {
                    movementDir = Vector2.ZERO;
                }
            }
        // Set velocity based on movement direction and speed
        setVelocity(movementDir.mult(MOVEMENT_SPEED));
    }
}
