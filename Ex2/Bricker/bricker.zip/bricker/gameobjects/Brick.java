package bricker.gameobjects;

import bricker.brick_strategies.CollisionStrategy;
import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

/**
 * Brick game object class representing a brick in the game.
 * Handles collisions with other objects using various collision strategies.
 */
public class Brick extends GameObject {
    // Collision strategy for the brick
    private final CollisionStrategy collisionStrategy;
    /**
     * Tag for identifying Brick
     */
    public static final String BRICK_TAG = "Brick";
    /**
     * Constructor for Brick.
     * @param topLeftCorner The top-left corner position of the brick.
     * @param dimensions The dimensions of the brick.
     * @param renderable The renderable for the brick.
     * @param collisionStrategy The collision strategy for the brick.
     */
    public Brick(Vector2 topLeftCorner, Vector2 dimensions,
                 Renderable renderable, CollisionStrategy collisionStrategy) {
        super(topLeftCorner, dimensions, renderable);
        this.collisionStrategy = collisionStrategy;
        this.setTag(BRICK_TAG);
    }

    /**
     * Method called on collision enter.
     * Passes the collision to the collision strategy for handling.
     * @param other The other game object involved in the collision.
     * @param collision The collision object containing collision information.
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        // Handle collision using the assigned collision strategy
        collisionStrategy.onCollision(this,other);
    }

}
