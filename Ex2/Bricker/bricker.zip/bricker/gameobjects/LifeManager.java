package bricker.gameobjects;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Vector2;
import java.awt.*;

/**
 * Manages the display and behavior of player lives.
 */
public class LifeManager extends GameObject {

    // GameManager instance for accessing game state
    private final BrickerGameManager brickerGameManager;
    // Current number of lives
    private int curNumOfLife;
    // Array of heart game objects representing lives
    private final GameObject[] arrOfHearts;
    // Maximum number of hearts
    private final int maxNumOfHearts;
    // Width of each heart
    private int heartWidth = 2;
    // Height of each heart
    private final int heartHeight;
    // Spacing between hearts
    private double spacing = 0.5;
    // Top-left corner position of the life manager
    private final Vector2 topLeftCorner;
    // Text game object for displaying life count
    private GameObject text;
    // Array of colors for life count text
    private final Color[] arrOfColors = {Color.red, Color.yellow, Color.green};

    /**
     * Constructor for LifeManager.
     * @param topLeftCorner The top-left corner position of the life manager.
     * @param dimensions The dimensions of the life manager.
     * @param renderable The renderable for the life manager.
     * @param brickerGameManager The game manager instance.
     * @param numOfHearts The initial number of hearts.
     * @param maxNumOfHearts The maximum number of hearts.
     * @param heartWidth The width of each heart.
     * @param heartHeight The height of each heart.
     * @param spacing The spacing between hearts.
     */
    public LifeManager(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                       BrickerGameManager brickerGameManager, int numOfHearts, int maxNumOfHearts,
                       int heartWidth, int heartHeight, double spacing) {
        super(topLeftCorner, dimensions, renderable);
        this.brickerGameManager = brickerGameManager;
        this.curNumOfLife = numOfHearts;
        this.maxNumOfHearts = maxNumOfHearts;
        this.arrOfHearts = new Heart[maxNumOfHearts];
        this.heartWidth = heartWidth;
        this.heartHeight = heartHeight;
        this.spacing = spacing;
        this.topLeftCorner = super.getTopLeftCorner();
    }


    /**
     * Initializes the life manager by creating heart game objects.
     */
    public void set(Renderable renderable) {
        for (int i = 0; i < maxNumOfHearts; i++) {
            arrOfHearts[i] = new Heart(new Vector2((float) (topLeftCorner.x() +
                    i * (heartWidth + spacing)), topLeftCorner.y()),
                    new Vector2(heartWidth, heartHeight), renderable);
        }
        for(int i = 0; i< curNumOfLife; i++){
            brickerGameManager.addObject(arrOfHearts[i], Layer.UI);
        }
        createText();
    }

    /**
     * Removes a heart from the display.
     */
    public void removeHeart()
    {
        brickerGameManager.eraseObject(arrOfHearts[curNumOfLife -1], Layer.UI);
        curNumOfLife--;
        setTextRenderer();
    }

    /**
     * Adds a heart to the display.
     */
    public void addHeart() {
        if (curNumOfLife < maxNumOfHearts) {
            brickerGameManager.addObject(arrOfHearts[curNumOfLife], Layer.UI);
            curNumOfLife++;
            brickerGameManager.setCurNumOfLife(curNumOfLife);
        }
        setTextRenderer();
    }

    /**
     * Creates the text game object for displaying life count.
     */
    private void createText() {
        TextRenderable textRenderable = new TextRenderable("Hearts: " + String.valueOf(curNumOfLife));
        GameObject text = new GameObject(new Vector2(20,
                brickerGameManager.getWindowDimantions().y() - 70), new Vector2(20, 20), textRenderable);
        this.text = text;
        textRenderable.setColor(Color.green);
        brickerGameManager.addObject(text, Layer.UI);
    }

    /**
     * Updates the text renderer to reflect the current life count.
     */
    public void setTextRenderer() {
        TextRenderable textRenderable = new TextRenderable("Hearts: " + String.valueOf(curNumOfLife));
        if (curNumOfLife >= 3) {
            textRenderable.setColor(arrOfColors[2]);
        } else {
            textRenderable.setColor(arrOfColors[curNumOfLife - 1]);
        }
        text.renderer().setRenderable(textRenderable);
    }
}
