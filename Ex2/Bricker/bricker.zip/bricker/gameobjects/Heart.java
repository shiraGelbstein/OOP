package bricker.gameobjects;

import danogl.GameObject;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

/**
 * Represents a heart game object in the game.
 * A basic game object without specific behavior.
 */
public class Heart extends GameObject {
    /**
     * Constructor for Heart.
     * @param topLeftCorner The top-left corner position of the heart.
     * @param dimensions The dimensions of the heart.
     * @param renderable The renderable for the heart.
     */
    public Heart(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable) {
        super(topLeftCorner, dimensions, renderable);
    }
}
