package bricker.gameobjects;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.Sound;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

/**
 * Represents a puck game object in the game.
 * Extends Ball class to inherit collision behavior.
 */
public class Puck extends Ball{

    /**
     * Tag for identifying puck
     */
    public static final String PUCK_TAG = "Puck";
    // Strategy for handling puck behavior
    private final PuckGameStrategy strategy;

    /**
     * Constructor for Puck.
     * @param topLeftCorner The top-left corner position of the puck.
     * @param dimensions The dimensions of the puck.
     * @param renderable The renderable for the puck.
     * @param collisionSound The collision sound for the puck.
     * @param strategy The strategy for handling puck behavior.
     */
    public Puck(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                Sound collisionSound , PuckGameStrategy strategy) {
        super(topLeftCorner, dimensions, renderable, collisionSound);
        this.strategy = strategy;
        this.setTag(PUCK_TAG);
    }

    /**
     * Method called on collision enter.
     * Calls super method to handle collision behavior.
     * @param other The other game object involved in the collision.
     * @param collision The collision object containing collision information.
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
    }

    /**
     * Method called on update.
     * Updates puck strategy based on current state.
     * @param deltaTime The time elapsed since the last frame.
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        // Update puck strategy
        strategy.updatePuckStrategy(this);
    }
}
