package bricker.gameobjects;

import danogl.collisions.GameObjectCollection;
import danogl.util.Vector2;

/**
 * Strategy for handling puck behavior.
 * Manages updating the puck based on position.
 */
public class PuckGameStrategy {

    // Collection of game objects for managing the puck
    private final GameObjectCollection gameObjects;
    // Dimensions of the game window
    private final Vector2 windowDimensions;

    /**
     * Constructor for PuckGameStrategy.
     * @param gameObjects The collection of game objects.
     * @param windowDimensions1 The dimensions of the game window.
     */
    public PuckGameStrategy(GameObjectCollection gameObjects, Vector2 windowDimensions1) {
        this.gameObjects = gameObjects;
        this.windowDimensions = windowDimensions1;
    }

    /**
     * Updates the puck strategy based on its position.
     * If the puck goes beyond the window dimensions, it is removed.
     * @param puck The puck game object.
     */
    public void updatePuckStrategy(Puck puck){

        if(puck.getCenter().y() > windowDimensions.y()) {
            gameObjects.removeGameObject(puck);
        }
    }
}
