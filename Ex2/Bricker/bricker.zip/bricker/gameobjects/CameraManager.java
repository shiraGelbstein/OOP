package bricker.gameobjects;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

/**
 * Camera manager game object class responsible for managing the camera in the game.
 * Monitors ball collisions to control camera behavior.
 */
public class CameraManager extends GameObject {
    private final BrickerGameManager brickerGameManager;
    private  int ballCollisionWhenEnter;

    /**
     * Constructs a CameraManager game object.
     *
     * @param topLeftCorner        The top-left corner position of the camera.
     * @param dimensions           The dimensions of the camera.
     * @param renderable           The renderable object associated with the camera.
     * @param brickerGameManager   The BrickerGameManager responsible for the game.
     */
    public CameraManager(Vector2 topLeftCorner, Vector2 dimensions,
                         Renderable renderable, BrickerGameManager brickerGameManager) {
        super(topLeftCorner, dimensions, renderable);
        this.brickerGameManager = brickerGameManager;
        this.ballCollisionWhenEnter = brickerGameManager.getBall().getCollisionCounter();
    }

    /**
     * Updates the CameraManager's state - if ball collided 4 time
     * or more ,sets the camera to null = stops the camera.
     *
     * @param deltaTime The time passed since the last update.
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if(!(brickerGameManager.camera() == null) &&
                (brickerGameManager.getBall().getCollisionCounter() != ballCollisionWhenEnter) &&
                (brickerGameManager.getBall().getCollisionCounter() - ballCollisionWhenEnter >= 4)){
            brickerGameManager.setCamera(null);
            brickerGameManager.eraseObject(this, Layer.UI);
        }

    }

    /**
     * Gets the number of collisions involving the ball since the last reset.
     * @return The number of collisions.
     */
    public int getCollisionCounter(){
        return brickerGameManager.getBall().getCollisionCounter() - ballCollisionWhenEnter;
    }

    /**
     * Sets the collision counter to the current number of ball collisions.
     */
    public void setCollisionCounter(){
        ballCollisionWhenEnter = brickerGameManager.getBall().getCollisionCounter();
    }
}
