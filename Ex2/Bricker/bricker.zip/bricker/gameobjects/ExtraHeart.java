package bricker.gameobjects;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

/**
 * Represents an extra heart game object in the game.
 * Handles collisions and updates based on a specific strategy.
 */
public class ExtraHeart extends Heart{
    private final ExtraHeartStrategy extraHeartStrategy;

    /**
     * Constructor for ExtraHeart.
     * @param topLeftCorner The top-left corner position of the extra heart.
     * @param dimensions The dimensions of the extra heart.
     * @param renderable The renderable for the extra heart.
     * @param extraHeartStrategy The strategy for handling extra heart behavior.
     */
    public ExtraHeart(Vector2 topLeftCorner, Vector2 dimensions,
                      Renderable renderable, ExtraHeartStrategy extraHeartStrategy) {
        super(topLeftCorner, dimensions, renderable);
        this.extraHeartStrategy = extraHeartStrategy;
        this.setTag("ExtraHeart");
    }


    /**
     * Method called on collision enter.
     * Passes the collision to the extra heart strategy for handling.
     * @param other The other game object involved in the collision.
     * @param collision The collision object containing collision information.
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        extraHeartStrategy.updateHearts(this,other);
    }

    /**
     * Method called on update.
     * Updates bounds based on the extra heart strategy.
     * @param deltaTime The time elapsed since the last frame.
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        extraHeartStrategy.updateBounds(this);
    }
}
