package bricker.gameobjects;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.Sound;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

import java.util.Objects;

/**
 * Ball game object class representing the main ball in the game.
 * Handles collisions with other objects and keeps track of collision count.
 */
public class Ball extends GameObject{

    /**
     * Tag for identifying the main ball
     */
    public static final String MAIN_BALL = "MainBall";
    // Counter for collisions
    private int collisionCounter = 0;
    // Sound for collision
    private final Sound collisionSound;

    /**
     * Constructor for Ball.
     * @param topLeftCorner The top-left corner position of the ball.
     * @param dimensions The dimensions of the ball.
     * @param renderable The renderable for the ball.
     * @param collisionSound The sound to be played on collision.
     */
    public Ball(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable, Sound collisionSound) {
        super(topLeftCorner, dimensions, renderable);
        this.collisionSound = collisionSound;
        this.setTag(MAIN_BALL);
    }

    /**
     * Method called on collision enter.
     * Reverses the velocity of the ball upon collision and plays the collision sound.
     * Increments the collision counter.
     * @param other The other game object involved in the collision.
     * @param collision The collision object containing collision information.
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        // Reverse velocity based on collision normal
        if (!Objects.equals(other.getTag(), "ExtraHeart")){
        Vector2 newVal = getVelocity().flipped(collision.getNormal());
        setVelocity(newVal);
        collisionSound.play();
        collisionCounter++;}
    }

    /**
     * return the collisionCounter.
     * @return the collisionCounter.
     */
    public int getCollisionCounter() {

        return collisionCounter;
    }

    /**
     * Method called on collision stay.
     * @param other The other game object involved in the collision.
     * @param collision The collision object containing collision information.
     */
    @Override
    public void onCollisionStay(GameObject other, Collision collision) {
        super.onCollisionStay(other, collision);
    }

    /**
     * Method called on collision exit.
     * @param other The other game object involved in the collision.
     */
    @Override
    public void onCollisionExit(GameObject other) {
        super.onCollisionExit(other);
    }
}