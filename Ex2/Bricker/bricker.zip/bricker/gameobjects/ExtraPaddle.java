package bricker.gameobjects;


import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

import java.util.Objects;

/**
 * Represents an extra paddle game object in the game.
 * Handles collisions and updates based on a specific strategy.
 */
public class ExtraPaddle extends Paddle {
    /**
     * Tag for identifying extra paddle
     */
    static public String EXTRA_PADDLE = "ExtraPaddle";
    // Strategy for handling extra paddle behavior
    private final ExtraPaddleStrategy extraPaddleStrategy;
    /**
     *  Counter for collisions
     */
    public int collisionCounter = 0;

    /**
     * Constructor for ExtraPaddle.
     * @param topLeftCorner The top-left corner position of the extra paddle.
     * @param dimensions The dimensions of the extra paddle.
     * @param renderable The renderable for the extra paddle.
     * @param userInputListener The user input listener for the extra paddle.
     * @param windowDimensions The dimensions of the game window.
     * @param extraPaddleStrategy The strategy for handling extra paddle behavior.
     */
    public ExtraPaddle(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                       UserInputListener userInputListener,
                       Vector2 windowDimensions,ExtraPaddleStrategy extraPaddleStrategy) {
        super(topLeftCorner, dimensions, renderable, userInputListener, windowDimensions);
        this.extraPaddleStrategy = extraPaddleStrategy;
        this.setTag(EXTRA_PADDLE);
    }

    /**
     * Getter for collision counter.
     * @return The collision counter value.
     */
    public int getCollisionCounter() {
        return collisionCounter;
    }

    /**
     * Method called on collision enter.
     * Updates collision counter and calls strategy method based on collision.
     * @param other The other game object involved in the collision.
     * @param collision The collision object containing collision information.
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        // Increment collision counter if collision is with the ball
        if(Objects.equals(other.getTag(), Ball.MAIN_BALL) || Objects.equals(other.getTag(), Puck.PUCK_TAG)){
            collisionCounter++;
        }
        // Update extra paddle strategy based on collision counter
        extraPaddleStrategy.updateWithCollisionCounter(this);
    }
}
