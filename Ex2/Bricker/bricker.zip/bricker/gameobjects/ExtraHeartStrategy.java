package bricker.gameobjects;

import bricker.main.BrickerGameManager;
import danogl.GameObject;
import danogl.collisions.Layer;

import java.util.Objects;

/**
 * Strategy for handling extra heart behavior.
 * Manages updating hearts and bounds based on collisions and positions.
 */
public class ExtraHeartStrategy {
    private final BrickerGameManager brickerGameManager;

    /**
     * Constructor for ExtraHeartStrategy.
     * @param brickerGameManager The game manager instance.
     */
    public ExtraHeartStrategy(BrickerGameManager brickerGameManager) {
        this.brickerGameManager = brickerGameManager;
    }

    /**
     * Updates hearts based on collision with another game object.
     * @param extraHeart The extra heart game object involved in the collision.
     * @param other The other game object involved in the collision.
     */
    public void updateHearts(ExtraHeart extraHeart, GameObject other){
        // If the collision is with the paddle, add a life
        if(Objects.equals(other.getTag(), Paddle.PADDLE)){
            brickerGameManager.eraseObject(extraHeart, Layer.DEFAULT);
            brickerGameManager.addLife();
        }
    }

    /**
     * Updates bounds based on the position of the extra heart.
     * If the extra heart goes beyond the window dimensions, it is removed.
     * @param extraHeart The extra heart game object.
     */
    public void updateBounds(ExtraHeart extraHeart) {
            if(extraHeart.getCenter().y() > brickerGameManager.getWindowDimantions().y()) {
                brickerGameManager.eraseObject(extraHeart,Layer.DEFAULT);
            }
    }
}
