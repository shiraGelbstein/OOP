import java.awt.image.renderable.ContextualRenderedImageFactory;

public class Game {
    static int DEFAULT_WIN_STREAK = 3;
    Player playerX;
    Player playerO;
    Renderer renderer;
    int winStreak;
    Board gameBoard;
    Game(Player playerX, Player playerO, Renderer renderer){
        gameBoard = new Board();
        this.playerX = playerX;
        this.playerO = playerO;
        this.renderer=renderer;
        this.winStreak = DEFAULT_WIN_STREAK;
    }

    Game(Player playerX,Player playerO, int size, int winStreak,Renderer renderer){
        gameBoard = new Board(size);
        this.playerX = playerX;
        this.playerO = playerO;
        this.renderer=renderer;
        if(winStreak>=2 && winStreak<= gameBoard.getSize() && winStreak<=gameBoard.getSize()){
            this.winStreak = winStreak;
        }
        else{
            this.winStreak = gameBoard.getSize();
        }
    }

    //getters
    public int getWinStreak(){
        return winStreak;
    }

    public int  getBoardSize(){
        return gameBoard.getSize();
    }

    //methods
    private boolean isWin()
    {
       for(int row = 0; row< gameBoard.getSize();row++)
       {
           for(int col=0; col<gameBoard.getSize();col++)
           {
               Mark curMark = gameBoard.getMark(row,col); //checking the symbol
               if(curMark==Mark.BLANK){continue;} //if symbol empty it is surely not a win
               int leftCounter = 1;
               int downCounter = 1;
               int diagonLeftCounter =1;
               int diagonRightCounter =1;

               for(int i=1;i<winStreak;i++)
               {
                   if(gameBoard.getMark(row,col+i)==curMark) {
                       leftCounter++;
                   }
                   if(gameBoard.getMark(row+i,col)==curMark) {
                       downCounter++;
                   }
                   if(gameBoard.getMark(row+i,col+i)==curMark) {
                       diagonLeftCounter++;
                   }
                   if(gameBoard.getMark(row-i,col-i)==curMark) {
                       diagonRightCounter++;
                   }
               }
               if(leftCounter == winStreak || downCounter == winStreak ||
                       diagonLeftCounter==winStreak || diagonRightCounter==winStreak)
               {
                   return true;
               }

           }
       }
       return false;
    }






    private boolean isGameOver() {
        for (int row = 0; row < gameBoard.getSize(); row++) {
            for (int col = 0; col < gameBoard.getSize(); col++) {
                if (gameBoard.getMark(row, col) == Mark.BLANK) {
                    return false;
                }
            }
        }
        return true;
    }

    public Mark run() {
        int counter = 0;
        Mark curPlayerMark = Mark.BLANK;
        Player cur_player;
        while(!isWin() && !isGameOver())
        {
            if(counter%2 == 0) {
                curPlayerMark = Mark.X;
                cur_player = playerX;
            }
            else{
                curPlayerMark = Mark.O;
                cur_player = playerO;
            }
            counter++;
            cur_player.playTurn(gameBoard,curPlayerMark);

        renderer.renderBoard(gameBoard);
        }
        if(isWin()) {

            return curPlayerMark;
        }
    return Mark.BLANK;
    }
}

