public class GeniusPlayer implements Player {
    public GeniusPlayer(){}


    private boolean is_legal_to_mark(int row, int col,Board board) {
        return 0 <= row && row < board.getSize() && 0 <= col &&
                col < board.getSize() && (board.getMark(row,col) == Mark.BLANK);
    }
    private int bestCurMove(Board board, Mark mark) {
        int curBest = -1;
        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                Mark curMark = board.getMark(row, col); //checking the symbol
                if (curMark != mark ) {
                    continue;
                } //if it is not the player's mark
                int leftCounter = 1;
                int downCounter = 1;
                int diagonLeftCounter = 1;
                int diagonRightCounter = 1;
                for (int i = 1; i < board.getSize(); i++) {
                    if (board.getMark(row, col + i) == curMark) {
                        leftCounter++;
                        if (leftCounter >= Math.max(downCounter,
                                Math.max(diagonLeftCounter, diagonRightCounter))
                                && is_legal_to_mark(row, col + i + 1,board)) {
                            curBest = row * 10 + (col + i + 1);
                        }
                    }
                    if (board.getMark(row + i, col) == curMark) {
                        downCounter++;
                        if (downCounter >= Math.max(leftCounter,
                                Math.max(diagonLeftCounter, diagonRightCounter))
                                && is_legal_to_mark(row + i + 1, col,board)) {
                            curBest = (row + i + 1) * 10 + col;
                        }
                    }
                    if (board.getMark(row + i, col + i) == curMark) {
                        diagonLeftCounter++;
                        if (downCounter >= Math.max(leftCounter,
                                Math.max(downCounter, diagonRightCounter))
                                && is_legal_to_mark(row + i + 1, col + i + 1,board)) {
                            curBest = (row + i + 1) * 10 + (col + i + 1);
                        }
                    }
                    if (board.getMark(row - i, col - i) == curMark) {
                        diagonRightCounter++;
                        if (downCounter >= Math.max(leftCounter,
                                Math.max(downCounter, diagonLeftCounter))
                                && is_legal_to_mark(row - 1 - i, col - i - 1,board)) {
                            curBest = (row - i - 1) * 10 + (col - i - 1);
                        }
                    }
                }
            }
        }
        return curBest;
    }


    public void playTurn(Board board, Mark mark) {
        int curBest = bestCurMove(board, mark);
        if (curBest < 0) {
            WhateverPlayer cp = new WhateverPlayer();
            cp.playTurn(board, mark);
        } else {
            board.putMark(mark, curBest / 10, curBest % 10);
        }
    }
}

