import java.util.Random;

public class CleverPlayer implements Player{
    public CleverPlayer() {}

    @Override
    public void playTurn(Board board, Mark mark) {
        Random rand = new Random();
        int randomInt = rand.nextInt(0,100);
        if(randomInt<55) {
            WhateverPlayer wp = new WhateverPlayer();
            wp.playTurn(board,mark);
        }
        else{
            GeniusPlayer gp = new GeniusPlayer();
            gp.playTurn(board,mark);
        }
    }
}
