public class HumanPlayer implements Player {
    public final static String INVALID_COORDINATE = "Invalid mark position, " +
            "please choose a different position.\nInvalid coordinates, type again: ";

    public final static String OCCUPIED_COORDINATE = "Mark position is already occupied.\n" +
            "Invalid coordinates, type again: ";
    public static String playerRequestInputString(String markSymbol) {
        return "Player " + markSymbol + ", type coordinates: ";
    }

    public HumanPlayer(){}
    public void playTurn(Board board, Mark mark) {

        if(mark == Mark.X){
        System.out.println(playerRequestInputString("X"));
        }
        else{
            System.out.println(playerRequestInputString("O"));
        }

        while (true) {
            //the format is for ex:"31" when 3 is thw row and col is 1.
            int playerInput = KeyboardInput.readInt();

            if (playerInput < 10 && board.putMark(mark, 0, playerInput)) break;

            if (playerInput < 100 && board.putMark(mark, playerInput / 10, playerInput % 10)) break;

            if (board.getMark(playerInput / 10, playerInput % 10) != Mark.BLANK) {
                System.out.println(OCCUPIED_COORDINATE);//occupied coordinates message
            } else {
                System.out.println(INVALID_COORDINATE);//invalid coordinates message
            }
        }
    }
}

