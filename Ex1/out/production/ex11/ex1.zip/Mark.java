public enum Mark {BLANK,X,O}

