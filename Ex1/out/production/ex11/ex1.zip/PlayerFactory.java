public class PlayerFactory {
    public PlayerFactory(){}
    public Player buildPlayer(String type){
        Player player = null;
        switch(type){
            case("human"):
                player = new HumanPlayer();
                break;
            case("genius"):
                player = new GeniusPlayer();
                break;
            case("clever"):
                player = new CleverPlayer();
                break;
            case("whatever"):
                player = new WhateverPlayer();
            }
        return player;
    }
}
