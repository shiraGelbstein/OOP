import java.util.Locale;

public class Tournament {
    public final static String UNKNOWN_PLAYER_NAME =
            "Choose a player, and start again.\nThe players: [human, clever, whatever, genius]";

    public final static String UNKNOWN_RENDERER_NAME =
            "Choose a renderer, and start again. \nPlease choose one of the following [console, none]";

    static String[] PLAYERS_TYPES =  {"human","clever","whatever","genius"};
    static String[] RENDERS_TYPES =  {"none","console"};


    private final int rounds;
    private final Renderer renderer;
    private final Player player1;
    private final Player player2;

    public Tournament(int rounds, Renderer renderer, Player player1, Player player2) {
        this.rounds = rounds;
        this.renderer = renderer;
        this.player1 = player1;
        this.player2 = player2;
    }


    void playTournament(int size, int winStreak, String playerName1, String playerName2){
        int player1Wins=0;
        int player2Wins=0;
        int numOfTies=0;
        for(int i=0;i<rounds;i++){
            Game game ;
            if(i%2==0){ // in the even rounds the first player marks X
            game = new Game(player1,player2,size,winStreak,renderer);
            }
            else{ // in the uneven rounds the second player marks X
                game = new Game(player2,player1,size,winStreak,renderer);
            }
            Mark cur_winner_mark = game.run();
            if(i%2==0 && cur_winner_mark==Mark.X) { //if the round is an even number player 1 is an X.
                player1Wins++;
                continue;
            }
            if(i%2==0 && cur_winner_mark==Mark.O){ //if the round is even players 1 mark is O.
                player2Wins++;
                continue;
            }
            if(cur_winner_mark==Mark.O) {//round is uneven than player 1 is an O mark
                player1Wins++;
                continue;
            }
            if(cur_winner_mark==Mark.X){
                player2Wins++;
            }
            else{
                numOfTies++;
            }
        }
        System.out.printf("######### Results #########\n Player 1, %s" +
                " won: %d rounds\n Player 2, %s won: %d rounds\n Ties: %d\n"
                ,playerName1,player1Wins,playerName2,player2Wins,numOfTies);
    }







    public static boolean playerNameTypo(String arg){
        for(int i=0;i<PLAYERS_TYPES.length;i++)
        {
            if(arg.equalsIgnoreCase(PLAYERS_TYPES[i])){
                return false;
            }
        }
        return true;
    }

    public static boolean renderNameTypo(String arg)
    {
        for(int i=0;i< RENDERS_TYPES.length;i++)
        {
            if(arg.equalsIgnoreCase(RENDERS_TYPES[i])){
                return false;
            }
        }
        return true;
    }

    static public boolean illegalInput(String args3,String args4,String args5)
    {if (renderNameTypo(args3)) //checking render
        {
            System.out.println(UNKNOWN_RENDERER_NAME);
            return true;
        }
        if (playerNameTypo(args4)) //checking first player
        {
            System.out.println(UNKNOWN_PLAYER_NAME);
            return true;
        }
        if (playerNameTypo(args5)) //checking second player
        {
            System.out.println(UNKNOWN_PLAYER_NAME);
            return true;
        }
        return false;
    }



    public static void main(String[] args){
        if(illegalInput(args[3],args[4],args[5])) {
            return;
        }
        //converting args strings to int
        int numOfRounds = Integer.parseInt(args[0]);
        int boardSize = Integer.parseInt(args[1]);
        int winStreak = Integer.parseInt(args[2]);

        // assuming the players giving args3,args4 and args5 are totally valid
        String chosenRenderLowerCase = args[3].toLowerCase();
        String player1LowerCase = args[4].toLowerCase();
        String player2LowerCase = args[5].toLowerCase();

        //building the players and the render:
        RendererFactory rendererFactory = new RendererFactory();
        Renderer chosenRender = rendererFactory.buildRenderer(chosenRenderLowerCase,boardSize);

        PlayerFactory playerFactory = new PlayerFactory();
        Player player1 = playerFactory.buildPlayer(player1LowerCase);
        Player player2 = playerFactory.buildPlayer(player2LowerCase);

        //finally running the tournament
        Tournament tournament = new
                Tournament(numOfRounds,chosenRender,player1,player2);
        tournament.playTournament(boardSize,winStreak,player1LowerCase,player2LowerCase);
    }
}




