public interface Player {
    void playTurn(Board board, Mark mark);
}
