public interface Renderer {
    public void renderBoard(Board board);
}
