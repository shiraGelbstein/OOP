import java.lang.reflect.Array;
import java.util.Scanner;

public class Chat {

        public static void main(String[] args) {
                String[] stringArray1 = new String[]{"what ", "should i say "};
                String[] stringArray3 = new String[]{"say <phrase> ok ill say <phrase>: <phrase>! "};
                ChatterBot chatter1= new ChatterBot("Shira", stringArray3,stringArray1);
                String[] stringArray2 = new String[]{"whaaat ", "say say "};
                String[] stringArray4 = new String[]{"haha halourios, but ill say it: <phrase>. "};
                ChatterBot chatter2= new ChatterBot("Tali",stringArray4,stringArray2);
                ChatterBot[] arrofchatter = {chatter1,chatter2};
                String statement = "say boo";
                //int x=0;
                while(true){
                     for(ChatterBot bot : arrofchatter)
                     {
                             statement = bot.replyTo(statement);
                             System.out.print(bot.getName()+": ");
                             System.out.print(statement);
                             System.out.print("\n");
                             //x++;
                     }
                }

        }
}
